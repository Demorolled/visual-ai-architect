# Round-12 Defects — 3D probe-failure fix round

Train rows: 67 (90/10 split, val kept offline).
Config: QLoRA 4-bit Qwen2.5-7B-Instruct-Uncensored · seq 2048 · 3 epochs · grad-accum 4 · LR 5e-5 continuation from the REAL R11 LoRA · --no-gguf (merged 16-bit safetensors; GGUF converted locally).
≈ 48 optimizer steps ≈ ~0.6 h on 1× T4.
