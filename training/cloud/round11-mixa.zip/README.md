# Round-11 Mix A — 3D GUI + verified + buildladder + retention top-up

Train rows: 114 (90/10 split, val kept offline).
Config: QLoRA 4-bit Qwen2.5-7B-Instruct-Uncensored · seq 2048 · 2 epochs · LR 5e-5 continuation from the R10 adapter · batch 1 · grad-accum 8 · --no-gguf (merged 16-bit safetensors; GGUF converted locally).
Projected: ~3.5 h on 1× T4.
